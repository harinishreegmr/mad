package com.example.fda

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.appcompat.app.AppCompatActivity
import com.example.fda.databinding.ActivitySplashBinding

class SplashActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySplashBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySplashBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.logoContainer.alpha = 0f
        binding.logoContainer.scaleX = 0.92f
        binding.logoContainer.scaleY = 0.92f
        binding.logoContainer.animate()
            .alpha(1f)
            .scaleX(1f)
            .scaleY(1f)
            .setDuration(450)
            .setStartDelay(120)
            .start()

        Handler(Looper.getMainLooper()).postDelayed({
            val next = if (SessionManager.isLoggedIn(this)) {
                Intent(this, RoleSelectionActivity::class.java)
            } else {
                Intent(this, LoginActivity::class.java)
            }
            next.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(next)
            finish()
        }, 1700)
    }
}

