package com.example.fda

import android.os.Bundle
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import com.example.fda.databinding.ActivityMapBinding
import com.mapbox.geojson.Point
import com.mapbox.maps.CameraOptions
import com.mapbox.maps.Style
import com.mapbox.maps.plugin.annotation.annotations
import com.mapbox.maps.plugin.annotation.generated.PointAnnotationOptions
import com.mapbox.maps.plugin.annotation.generated.createPointAnnotationManager

class MapActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMapBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMapBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.backButton.setOnClickListener {
            finish()
        }

        logTokenStatus()
        setupMap()
    }

    override fun onStart() {
        super.onStart()
        binding.mapView.onStart()
    }

    override fun onStop() {
        binding.mapView.onStop()
        super.onStop()
    }

    override fun onLowMemory() {
        super.onLowMemory()
        binding.mapView.onLowMemory()
    }

    override fun onDestroy() {
        binding.mapView.onDestroy()
        super.onDestroy()
    }

    private fun logTokenStatus() {
        val token = runCatching { getString(R.string.mapbox_access_token) }.getOrNull().orEmpty()
        if (token.isBlank()) {
            Log.e(TAG, "Mapbox token is empty. Set MAPBOX_PUBLIC_TOKEN in local.properties / gradle.properties.")
        } else {
            Log.d(TAG, "Mapbox token present. length=${token.length}")
        }
    }

    private fun setupMap() {
        runCatching {
            binding.mapView.mapboxMap.loadStyleUri(Style.MAPBOX_STREETS) { _ ->
                Log.d(TAG, "Map style loaded.")
                addMarkers(DonationRepository.donations)

                val availableDonations =
                    DonationRepository.donations.filter { !it.isAccepted && it.latitude != null && it.longitude != null }
                val centerPoint = if (availableDonations.isNotEmpty()) {
                    val first = availableDonations.first()
                    Point.fromLngLat(first.longitude!!, first.latitude!!)
                } else {
                    Point.fromLngLat(77.5946, 12.9716) // Default center
                }

                binding.mapView.mapboxMap.setCamera(
                    CameraOptions.Builder()
                        .center(centerPoint)
                        .zoom(10.0)
                        .build()
                )
            }
        }.onFailure { t ->
            Log.e(TAG, "Failed to initialize Mapbox map.", t)
        }
    }

    private fun addMarkers(donations: List<Donation>) {
        val annotationApi = binding.mapView.annotations
        val pointAnnotationManager = annotationApi.createPointAnnotationManager()
        pointAnnotationManager.deleteAll()

        donations
            .filter { !it.isAccepted && it.latitude != null && it.longitude != null }
            .forEach { donation ->
            val pointAnnotationOptions: PointAnnotationOptions = PointAnnotationOptions()
                .withPoint(Point.fromLngLat(donation.longitude!!, donation.latitude!!))
                .withTextField(donation.foodName)
            
            pointAnnotationManager.create(pointAnnotationOptions)
        }
    }

    private companion object {
        private const val TAG = "MapActivity"
    }
}
