package com.example.fda

import android.content.Context
import android.telephony.SmsManager

object SmsHelper {
    private val phoneRegex = Regex("^\\+?[0-9]{10,15}$")

    fun isValidPhone(phone: String?): Boolean {
        val p = phone?.trim().orEmpty()
        return p.isNotBlank() && phoneRegex.matches(p)
    }

    fun sendAcceptanceSms(
        context: Context,
        donorPhone: String?,
        message: String = "Your donation has been accepted. Please coordinate pickup."
    ): Result<Unit> {
        val phone = donorPhone?.trim().orEmpty()
        if (!isValidPhone(phone)) return Result.failure(IllegalArgumentException("Invalid phone number"))

        return runCatching {
            val smsManager = SmsManager.getDefault()
            smsManager.sendTextMessage(phone, null, message, null, null)
        }
    }
}

