package com.example.fda

import android.net.Uri
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.view.isVisible
import androidx.recyclerview.widget.RecyclerView
import com.example.fda.databinding.ItemDonationCardBinding

class DonationAdapter(
    private var donations: List<Donation>,
    private val onAcceptClick: (Donation) -> Unit
) : RecyclerView.Adapter<DonationAdapter.DonationViewHolder>() {

    inner class DonationViewHolder(private val binding: ItemDonationCardBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(donation: Donation) {
            binding.foodName.text = donation.foodName
            binding.foodQuantity.text = "Quantity: ${donation.quantity}"
            binding.expiryTime.text = "Expires in: ${donation.expiryHours} hours"
            binding.foodType.text = "Type: ${donation.foodType}"
            binding.donorName.text = if (donation.isAnonymous) "Donor: Anonymous" else "Donor: ${donation.donorName}"

            val imageUri = donation.imageUri?.let { runCatching { Uri.parse(it) }.getOrNull() }
            binding.donationImage.isVisible = imageUri != null
            if (imageUri != null) {
                binding.donationImage.setImageURI(imageUri)
            } else {
                binding.donationImage.setImageDrawable(null)
            }

            binding.playAudioButton.isVisible = !donation.audioPath.isNullOrBlank()
            binding.playAudioButton.setOnClickListener {
                val path = donation.audioPath ?: return@setOnClickListener
                runCatching { AudioNoteRecorder.play(path) }
            }

            if (donation.isAccepted) {
                binding.acceptButton.text = "Accepted"
                binding.acceptButton.isEnabled = false
            } else {
                binding.acceptButton.text = "Accept Donation"
                binding.acceptButton.isEnabled = true
                binding.acceptButton.setOnClickListener { onAcceptClick(donation) }
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): DonationViewHolder {
        val binding = ItemDonationCardBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return DonationViewHolder(binding)
    }

    override fun onBindViewHolder(holder: DonationViewHolder, position: Int) {
        holder.bind(donations[position])
    }

    override fun getItemCount(): Int = donations.size

    fun updateData(newDonations: List<Donation>) {
        donations = newDonations
        notifyDataSetChanged()
    }
}
