package com.example.fda

object DonationRepository {
    private val _donations = mutableListOf<Donation>()
    val donations: List<Donation> get() = _donations

    private var donorScore = 0

    init {
        // Sample data
        _donations.add(
            Donation(
                id = "1",
                foodName = "Pasta",
                quantity = "3 portions",
                expiryHours = 5,
                foodType = "Veg",
                donorName = "Alice",
                isAnonymous = false,
                latitude = 12.9716,
                longitude = 77.5946
            )
        )
        _donations.add(
            Donation(
                id = "2",
                foodName = "Chicken Curry",
                quantity = "2kg",
                expiryHours = 3,
                foodType = "Non-Veg",
                donorName = "Bob",
                isAnonymous = false,
                latitude = 12.9352,
                longitude = 77.6245
            )
        )
        _donations.add(
            Donation(
                id = "3",
                foodName = "Salad",
                quantity = "5 packs",
                expiryHours = 8,
                foodType = "Vegan",
                donorName = "Charlie",
                isAnonymous = true,
                latitude = 12.9716,
                longitude = 77.6411
            )
        )
    }

    fun addDonation(donation: Donation) {
        val newDonation = donation.copy(id = System.currentTimeMillis().toString())
        _donations.add(newDonation)
    }

    fun acceptDonation(donationId: String) {
        val index = _donations.indexOfFirst { it.id == donationId }
        if (index != -1) {
            _donations[index] = _donations[index].copy(isAccepted = true)
            donorScore += 10
        }
    }

    fun getDonorScore(): Int = donorScore
}
