package com.example.fda

import android.Manifest
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.widget.Toast
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.fda.databinding.ActivityDonorHomeBinding
import com.example.fda.databinding.DialogAddDonationBinding
import com.google.android.material.snackbar.Snackbar
import java.io.File

class DonorHomeActivity : AppCompatActivity() {

    private lateinit var binding: ActivityDonorHomeBinding
    private lateinit var adapter: DonationAdapter

    private var addDialog: AlertDialog? = null
    private var addDialogBinding: DialogAddDonationBinding? = null

    private var selectedImageUri: Uri? = null
    private var pendingCameraUri: Uri? = null
    private var recordedAudioPath: String? = null
    private var currentLat: Double? = null
    private var currentLng: Double? = null

    private var audioRecorder: AudioNoteRecorder? = null

    private lateinit var requestPermissionsLauncher: ActivityResultLauncher<Array<String>>
    private lateinit var takePictureLauncher: ActivityResultLauncher<Uri>
    private lateinit var openDocumentLauncher: ActivityResultLauncher<Array<String>>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDonorHomeBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupLaunchers()
        setupRecyclerView()
        updateScore()

        binding.addDonationFab.setOnClickListener {
            showAddDonationDialog()
        }
    }

    override fun onDestroy() {
        audioRecorder?.release()
        audioRecorder = null
        super.onDestroy()
    }

    private fun setupRecyclerView() {
        adapter = DonationAdapter(DonationRepository.donations) { donation ->
            // In donor home, clicking might show status or delete option
        }
        binding.donationsRecyclerView.layoutManager = LinearLayoutManager(this)
        binding.donationsRecyclerView.adapter = adapter
    }

    private fun updateScore() {
        binding.donorScore.text = "Score: ${DonationRepository.getDonorScore()}"
    }

    private fun setupLaunchers() {
        requestPermissionsLauncher =
            registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { results ->
                val b = addDialogBinding ?: return@registerForActivityResult

                if (results[Manifest.permission.ACCESS_FINE_LOCATION] == true ||
                    results[Manifest.permission.ACCESS_COARSE_LOCATION] == true
                ) {
                    fetchLocationIntoDialog()
                }

                if (results[Manifest.permission.CAMERA] == true) {
                    launchCamera()
                }

                if (results[Manifest.permission.RECORD_AUDIO] == true) {
                    startRecording(b)
                }
            }

        takePictureLauncher =
            registerForActivityResult(ActivityResultContracts.TakePicture()) { success ->
                val b = addDialogBinding ?: return@registerForActivityResult
                if (success) {
                    selectedImageUri = pendingCameraUri
                    pendingCameraUri = null
                    showPreviewIfAny(b)
                } else {
                    pendingCameraUri = null
                }
            }

        openDocumentLauncher =
            registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
                val b = addDialogBinding ?: return@registerForActivityResult
                if (uri != null) {
                    // Persist read permission so cards can load later.
                    runCatching {
                        contentResolver.takePersistableUriPermission(
                            uri,
                            android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION
                        )
                    }
                    selectedImageUri = uri
                    showPreviewIfAny(b)
                }
            }
    }

    private fun showAddDonationDialog() {
        val dialogBinding = DialogAddDonationBinding.inflate(LayoutInflater.from(this))
        addDialogBinding = dialogBinding

        selectedImageUri = null
        pendingCameraUri = null
        recordedAudioPath = null
        currentLat = null
        currentLng = null

        dialogBinding.ivDonationPreview.visibility = View.GONE
        dialogBinding.tvAudioStatus.text = "Audio: none"
        dialogBinding.tvLocationStatus.text = "Location: fetching…"

        val dialog = AlertDialog.Builder(this)
            .setView(dialogBinding.root)
            .setOnDismissListener {
                audioRecorder?.release()
                audioRecorder = null
                addDialogBinding = null
                addDialog = null
            }
            .create()
        addDialog = dialog

        dialogBinding.btnCaptureImage.setOnClickListener {
            ensureCameraThenLaunch()
        }
        dialogBinding.btnSelectFromGallery.setOnClickListener {
            openDocumentLauncher.launch(arrayOf("image/*"))
        }
        dialogBinding.btnRecordAudio.setOnClickListener {
            ensureAudioThenStart(dialogBinding)
        }
        dialogBinding.btnStopAudio.setOnClickListener {
            stopRecording(dialogBinding)
        }

        ensureLocationThenFetch()

        dialogBinding.btnSubmitDonation.setOnClickListener {
            val name = dialogBinding.etFoodName.text.toString()
            val quantity = dialogBinding.etQuantity.text.toString()
            val expiry = dialogBinding.etExpiry.text.toString().toIntOrNull() ?: 0
            val donorPhone = dialogBinding.etDonorPhone.text?.toString()?.trim().orEmpty()
            val type = when (dialogBinding.rgFoodType.checkedRadioButtonId) {
                R.id.rbVeg -> "Veg"
                R.id.rbNonVeg -> "Non-Veg"
                R.id.rbVegan -> "Vegan"
                else -> "Veg"
            }
            val reveal = dialogBinding.cbRevealIdentity.isChecked

            if (name.isNotEmpty() && quantity.isNotEmpty()) {
                val newDonation = Donation(
                    foodName = name,
                    quantity = quantity,
                    expiryHours = expiry,
                    foodType = type,
                    donorName = "Current User", // Should be from Auth0 profile
                    isAnonymous = !reveal,
                    donorPhone = donorPhone.ifBlank { null },
                    imageUri = selectedImageUri?.toString(),
                    audioPath = recordedAudioPath,
                    latitude = currentLat,
                    longitude = currentLng
                )
                DonationRepository.addDonation(newDonation)
                adapter.updateData(DonationRepository.donations)
                NotificationHelper.notifyDonationAdded(this, newDonation)
                Snackbar.make(binding.root, "Donation added", Snackbar.LENGTH_SHORT).show()
                dialog.dismiss()
            } else {
                Toast.makeText(this, "Please enter food name and quantity.", Toast.LENGTH_SHORT).show()
            }
        }

        dialog.show()
    }

    private fun showPreviewIfAny(b: DialogAddDonationBinding) {
        val uri = selectedImageUri
        if (uri == null) {
            b.ivDonationPreview.visibility = View.GONE
            b.ivDonationPreview.setImageDrawable(null)
            return
        }
        b.ivDonationPreview.visibility = View.VISIBLE
        b.ivDonationPreview.setImageURI(uri)
    }

    private fun ensureLocationThenFetch() {
        val fine = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
        val coarse = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION)
        if (fine == PackageManager.PERMISSION_GRANTED || coarse == PackageManager.PERMISSION_GRANTED) {
            fetchLocationIntoDialog()
        } else {
            requestPermissionsLauncher.launch(
                arrayOf(
                    Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_COARSE_LOCATION
                )
            )
        }
    }

    private fun fetchLocationIntoDialog() {
        val b = addDialogBinding ?: return
        b.tvLocationStatus.text = "Location: fetching…"
        LocationHelper.fetchLastKnownLatLng(this) { lat, lng ->
            currentLat = lat
            currentLng = lng
            b.tvLocationStatus.text =
                if (lat != null && lng != null) "Location: $lat, $lng" else "Location: unavailable"
        }
    }

    private fun ensureCameraThenLaunch() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) ==
            PackageManager.PERMISSION_GRANTED
        ) {
            launchCamera()
        } else {
            requestPermissionsLauncher.launch(arrayOf(Manifest.permission.CAMERA))
        }
    }

    private fun launchCamera() {
        val photoDir = File(cacheDir, "camera").apply { mkdirs() }
        val photoFile = File(photoDir, "donation_${System.currentTimeMillis()}.jpg")
        val uri = FileProvider.getUriForFile(this, "${packageName}.fileprovider", photoFile)
        pendingCameraUri = uri
        takePictureLauncher.launch(uri)
    }

    private fun ensureAudioThenStart(b: DialogAddDonationBinding) {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) ==
            PackageManager.PERMISSION_GRANTED
        ) {
            startRecording(b)
        } else {
            requestPermissionsLauncher.launch(arrayOf(Manifest.permission.RECORD_AUDIO))
        }
    }

    private fun startRecording(b: DialogAddDonationBinding) {
        val recorder = (audioRecorder ?: AudioNoteRecorder(this).also { audioRecorder = it })
        if (recorder.isRecording()) return
        runCatching {
            recorder.start()
            b.tvAudioStatus.text = "Audio: recording…"
            b.btnRecordAudio.isEnabled = false
            b.btnStopAudio.isEnabled = true
        }.onFailure {
            Toast.makeText(this, "Unable to start recording.", Toast.LENGTH_SHORT).show()
        }
    }

    private fun stopRecording(b: DialogAddDonationBinding) {
        val recorder = audioRecorder ?: return
        val file = recorder.stop()
        recordedAudioPath = file?.absolutePath
        b.tvAudioStatus.text = if (!recordedAudioPath.isNullOrBlank()) "Audio: recorded" else "Audio: none"
        b.btnRecordAudio.isEnabled = true
        b.btnStopAudio.isEnabled = false
    }
}
