package com.example.fda

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.fda.databinding.ActivityRecipientHomeBinding
import com.google.android.material.snackbar.Snackbar

class RecipientHomeActivity : AppCompatActivity() {

    private lateinit var binding: ActivityRecipientHomeBinding
    private lateinit var adapter: DonationAdapter

    private lateinit var requestPermissionsLauncher: ActivityResultLauncher<Array<String>>
    private var pendingAcceptedDonation: Donation? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityRecipientHomeBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupPermissionLauncher()
        setupRecyclerView()
        setupFilters()
        
        binding.btnFindOnMap.setOnClickListener {
            startActivity(Intent(this, MapActivity::class.java))
        }
    }

    private fun setupPermissionLauncher() {
        requestPermissionsLauncher =
            registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { results ->
                val donation = pendingAcceptedDonation
                pendingAcceptedDonation = null

                // Notifications (optional)
                if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU ||
                    results[Manifest.permission.POST_NOTIFICATIONS] == true
                ) {
                    donation?.let { NotificationHelper.notifyDonationAccepted(this, it) }
                }

                // SMS (optional)
                if (results[Manifest.permission.SEND_SMS] == true) {
                    donation?.let { trySendSms(it) }
                }
            }
    }

    private fun setupRecyclerView() {
        adapter = DonationAdapter(DonationRepository.donations) { donation ->
            DonationRepository.acceptDonation(donation.id)
            Snackbar.make(binding.root, "Donation accepted: ${donation.foodName}", Snackbar.LENGTH_SHORT).show()
            handlePostAcceptSideEffects(donation)
            updateList()
        }
        binding.recipientRecyclerView.layoutManager = LinearLayoutManager(this)
        binding.recipientRecyclerView.adapter = adapter
    }

    private fun handlePostAcceptSideEffects(donation: Donation) {
        // 1) Local notification (push-style) - permission on Android 13+
        val needsPostNotif =
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
                ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) !=
                PackageManager.PERMISSION_GRANTED

        // 2) SMS - permission always runtime
        val needsSms =
            ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) !=
                PackageManager.PERMISSION_GRANTED

        if (!needsPostNotif && !needsSms) {
            NotificationHelper.notifyDonationAccepted(this, donation)
            trySendSms(donation)
            return
        }

        pendingAcceptedDonation = donation
        val perms = buildList {
            if (needsPostNotif) add(Manifest.permission.POST_NOTIFICATIONS)
            if (needsSms) add(Manifest.permission.SEND_SMS)
        }.toTypedArray()
        requestPermissionsLauncher.launch(perms)
    }

    private fun trySendSms(donation: Donation) {
        if (!SmsHelper.isValidPhone(donation.donorPhone)) {
            Snackbar.make(binding.root, "No valid donor phone number for SMS", Snackbar.LENGTH_SHORT).show()
            return
        }
        SmsHelper.sendAcceptanceSms(this, donation.donorPhone)
            .onSuccess {
                Snackbar.make(binding.root, "SMS sent to donor", Snackbar.LENGTH_SHORT).show()
            }
            .onFailure {
                Snackbar.make(binding.root, "SMS failed to send", Snackbar.LENGTH_SHORT).show()
            }
    }

    private fun setupFilters() {
        binding.filterChipGroup.setOnCheckedStateChangeListener { _, _ ->
            updateList()
        }
    }

    private fun updateList() {
        val chipId = binding.filterChipGroup.checkedChipId
        val filteredList = when (chipId) {
            R.id.chipVeg -> DonationRepository.donations.filter { it.foodType == "Veg" }
            R.id.chipNonVeg -> DonationRepository.donations.filter { it.foodType == "Non-Veg" }
            else -> DonationRepository.donations
        }
        adapter.updateData(filteredList)
    }
}
