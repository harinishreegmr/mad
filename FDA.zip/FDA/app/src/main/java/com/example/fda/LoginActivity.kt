package com.example.fda

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.auth0.android.Auth0
import com.auth0.android.authentication.AuthenticationException
import com.auth0.android.callback.Callback
import com.auth0.android.provider.WebAuthProvider
import com.auth0.android.result.Credentials
import com.example.fda.databinding.ActivityLoginBinding
import com.google.android.material.snackbar.Snackbar

class LoginActivity : AppCompatActivity() {

    private lateinit var binding: ActivityLoginBinding
    private lateinit var account: Auth0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)

        account = Auth0.getInstance(
            getString(R.string.com_auth0_client_id),
            getString(R.string.com_auth0_domain)
        )

        binding.loginButton.setOnClickListener {
            loginWithAuth0()
        }
    }

    private fun loginWithAuth0() {
        val scheme = getString(R.string.com_auth0_scheme)
        binding.loginButton.isEnabled = false
        binding.loginProgress.show()

        Log.d(TAG, "Starting Auth0 login. domain=${getString(R.string.com_auth0_domain)} scheme=$scheme")

        runCatching {
            WebAuthProvider.login(account)
                .withScheme(scheme)
                .withScope("openid profile email")
                .start(this, object : Callback<Credentials, AuthenticationException> {
                    override fun onFailure(error: AuthenticationException) {
                        Log.e(TAG, "Auth0 login failed.", error)
                        runOnUiThread {
                            binding.loginProgress.hide()
                            binding.loginButton.isEnabled = true
                            Snackbar.make(
                                binding.root,
                                "Login failed. Please try again.",
                                Snackbar.LENGTH_LONG
                            ).show()
                        }
                    }

                    override fun onSuccess(result: Credentials) {
                        Log.d(TAG, "Auth0 login success. Access token present=${result.accessToken != null}")
                        runOnUiThread {
                            SessionManager.setLoggedIn(this@LoginActivity, true)
                            binding.loginProgress.hide()
                            startActivity(Intent(this@LoginActivity, RoleSelectionActivity::class.java))
                            finish()
                        }
                    }
                })
        }.onFailure { t ->
            Log.e(TAG, "Auth0 login threw unexpectedly.", t)
            binding.loginProgress.hide()
            binding.loginButton.isEnabled = true
            Toast.makeText(this, "Login error. Please try again.", Toast.LENGTH_SHORT).show()
        }
    }

    private companion object {
        private const val TAG = "LoginActivity"
    }
}
