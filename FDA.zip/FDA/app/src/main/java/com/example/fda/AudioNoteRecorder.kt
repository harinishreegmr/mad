package com.example.fda

import android.content.Context
import android.media.MediaPlayer
import android.media.MediaRecorder
import java.io.File

class AudioNoteRecorder(private val context: Context) {
    private var recorder: MediaRecorder? = null
    private var outputFile: File? = null

    fun isRecording(): Boolean = recorder != null

    fun start(): File {
        stop()

        val dir = File(context.getExternalFilesDir(null), "audio_notes").apply { mkdirs() }
        val file = File(dir, "note_${System.currentTimeMillis()}.m4a")
        outputFile = file

        val r = MediaRecorder(context).apply {
            setAudioSource(MediaRecorder.AudioSource.MIC)
            setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            setOutputFile(file.absolutePath)
            prepare()
            start()
        }
        recorder = r
        return file
    }

    fun stop(): File? {
        val r = recorder ?: return outputFile
        try {
            r.stop()
        } catch (_: IllegalStateException) {
            // If stopped too quickly, just discard.
        } finally {
            r.reset()
            r.release()
            recorder = null
        }
        return outputFile
    }

    fun release() {
        stop()
    }

    companion object {
        fun play(path: String, onDone: (() -> Unit)? = null): MediaPlayer {
            val player = MediaPlayer().apply {
                setDataSource(path)
                setOnCompletionListener {
                    onDone?.invoke()
                    release()
                }
                prepare()
                start()
            }
            return player
        }
    }
}

