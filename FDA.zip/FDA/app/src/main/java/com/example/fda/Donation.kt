package com.example.fda

data class Donation(
    val id: String = "",
    val foodName: String,
    val quantity: String,
    val expiryHours: Int,
    val foodType: String, // Veg, Non-Veg, Vegan
    val donorName: String,
    val isAnonymous: Boolean,
    val donorPhone: String? = null,
    val imageUri: String? = null,
    val audioPath: String? = null,
    val latitude: Double? = null,
    val longitude: Double? = null,
    val isAccepted: Boolean = false
)
