package com.example.fda

import android.annotation.SuppressLint
import android.content.Context
import com.google.android.gms.location.LocationServices

object LocationHelper {
    @SuppressLint("MissingPermission")
    fun fetchLastKnownLatLng(
        context: Context,
        onResult: (lat: Double?, lng: Double?) -> Unit
    ) {
        val client = LocationServices.getFusedLocationProviderClient(context)
        client.lastLocation
            .addOnSuccessListener { loc ->
                onResult(loc?.latitude, loc?.longitude)
            }
            .addOnFailureListener {
                onResult(null, null)
            }
    }
}

