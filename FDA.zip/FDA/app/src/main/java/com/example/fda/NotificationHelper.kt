package com.example.fda

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.app.TaskStackBuilder
import androidx.core.content.ContextCompat

object NotificationHelper {
    private const val CHANNEL_ID = "donation_updates"
    private const val CHANNEL_NAME = "Donation updates"

    private fun ensureChannel(context: Context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val existing = manager.getNotificationChannel(CHANNEL_ID)
        if (existing != null) return

        val channel = NotificationChannel(
            CHANNEL_ID,
            CHANNEL_NAME,
            NotificationManager.IMPORTANCE_DEFAULT
        ).apply {
            description = "Notifications for donation activity"
            enableVibration(true)
        }
        manager.createNotificationChannel(channel)
    }

    private fun hasPostNotificationsPermission(context: Context): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) ==
                PackageManager.PERMISSION_GRANTED
        } else {
            true
        }
    }

    fun notifyDonationAdded(context: Context, donation: Donation) {
        if (!hasPostNotificationsPermission(context)) return
        ensureChannel(context)

        val targetIntent = Intent(context, RecipientHomeActivity::class.java)
        val pendingIntent = TaskStackBuilder.create(context)
            .addNextIntentWithParentStack(targetIntent)
            .getPendingIntent(
                donation.id.hashCode(),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

        val viewActionIntent = Intent(context, RecipientHomeActivity::class.java)
        val viewAction = PendingIntent.getActivity(
            context,
            donation.id.hashCode() + 1,
            viewActionIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("New donation added")
            .setContentText("${donation.foodName} (${donation.quantity})")
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)
            .setDefaults(NotificationCompat.DEFAULT_ALL) // sound + vibration (where allowed)
            .addAction(android.R.drawable.ic_menu_view, "View", viewAction)
            .build()

        NotificationManagerCompat.from(context).notify(donation.id.hashCode(), notification)
    }

    fun notifyDonationAccepted(context: Context, donation: Donation) {
        if (!hasPostNotificationsPermission(context)) return
        ensureChannel(context)

        val targetIntent = Intent(context, DonorHomeActivity::class.java)
        val pendingIntent = TaskStackBuilder.create(context)
            .addNextIntentWithParentStack(targetIntent)
            .getPendingIntent(
                donation.id.hashCode(),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

        val viewActionIntent = Intent(context, DonorHomeActivity::class.java)
        val viewAction = PendingIntent.getActivity(
            context,
            donation.id.hashCode() + 2,
            viewActionIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("Donation accepted")
            .setContentText("Your donation \"${donation.foodName}\" was accepted.")
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)
            .setDefaults(NotificationCompat.DEFAULT_ALL)
            .addAction(android.R.drawable.ic_menu_view, "View", viewAction)
            .build()

        NotificationManagerCompat.from(context).notify(donation.id.hashCode(), notification)
    }
}

