package com.example.fda

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.fda.databinding.ActivityRoleSelectionBinding

class RoleSelectionActivity : AppCompatActivity() {

    private lateinit var binding: ActivityRoleSelectionBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityRoleSelectionBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.donorCard.setOnClickListener {
            startActivity(Intent(this, DonorHomeActivity::class.java))
        }

        binding.recipientCard.setOnClickListener {
            startActivity(Intent(this, RecipientHomeActivity::class.java))
        }
    }
}
