plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
}

val mapboxPublicToken: String = providers.gradleProperty("MAPBOX_PUBLIC_TOKEN").orNull ?: ""

android {
    namespace = "com.example.fda"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.example.fda"
        minSdk = 24
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
        
        // Auth0 redirect intent-filter placeholders.
        // These must be literal values (NOT @string refs).
        manifestPlaceholders["auth0Domain"] = "dev-tn1p4katzcfb5nxm.us.auth0.com"
        manifestPlaceholders["auth0Scheme"] = "demo"

        // Mapbox runtime token. Configure via `local.properties` or `~/.gradle/gradle.properties`.
        // Example: MAPBOX_PUBLIC_TOKEN=pk....
        resValue("string", "mapbox_access_token", mapboxPublicToken)
        buildConfigField("String", "MAPBOX_PUBLIC_TOKEN", "\"$mapboxPublicToken\"")
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_11
        targetCompatibility = JavaVersion.VERSION_11
    }
    kotlinOptions {
        jvmTarget = "11"
    }
    buildFeatures {
        viewBinding = true
        buildConfig = true
    }
}

dependencies {
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.appcompat)
    implementation(libs.material)
    implementation(libs.androidx.activity)
    implementation(libs.androidx.constraintlayout)
    implementation(libs.play.services.location)
    
    // Auth0
    implementation(libs.auth0)
    
    // Mapbox
    implementation(libs.mapbox.maps)

    testImplementation(libs.junit)
    androidTestImplementation(libs.androidx.junit)
    androidTestImplementation(libs.androidx.espresso.core)
}
